#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Leakage-checked, 77-province, one-week-ahead dengue model pipeline.

This pipeline deliberately keeps the model-development data contract separate
from the website's publication contract. It creates derived artifacts and a
training manifest, but does not publish them to Production or invent outbreak
risk thresholds.

Commands:
  python national_model_pipeline.py audit --train-csv train.csv --full-csv full.csv
  python national_model_pipeline.py train --train-csv train.csv --full-csv full.csv \
      --source-commit <40-char-git-sha> --output-dir artifacts

Dependencies for `train`: numpy and lightgbm. Audit and contract tests use only
the Python standard library.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
import statistics
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

EXPECTED_PROVINCES = 77
CASE_LAGS = (1, 2, 3, 4, 8, 12)
FEATURES = (
    "cases_L1", "cases_L2", "cases_L3", "cases_L4", "cases_L8", "cases_L12",
    "outbreak_momentum", "cases_L1_relative", "cases_L2_relative",
    "sin_week", "cos_week", "w_apparent_temperature_mean_L1",
)
SOURCE_REPOSITORY = "https://github.com/johnlovepizza/DenguYosoku"
TANRABAD_SOURCE = "https://trb.ddc.moph.go.th/"


class DataContractError(ValueError):
    """Raised when a source dataset violates the declared panel contract."""


@dataclass(frozen=True)
class PanelRow:
    province: str
    week_start: date
    week: int
    cases: float | None
    weather: float | None

    @property
    def key(self) -> tuple[str, date]:
        return (self.province, self.week_start)


@dataclass(frozen=True)
class FeatureRow:
    province: str
    week_start: date
    week: int
    target: float | None
    values: tuple[float, ...]


def parse_optional_number(value: str | None, *, field: str, line: int) -> float | None:
    text = (value or "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except ValueError as exc:
        raise DataContractError(f"line {line}: {field} is not numeric: {text!r}") from exc
    if not math.isfinite(number):
        raise DataContractError(f"line {line}: {field} must be finite")
    return number


def read_panel(path: Path, *, allow_blank_target_week: bool = False) -> list[PanelRow]:
    """Read only the modelling columns; extra columns in dengue_full.csv are ignored."""
    if not path.is_file():
        raise FileNotFoundError(f"Input CSV not found: {path}")

    required = {"province", "week_start", "cases", "w_apparent_temperature_mean"}
    rows: list[PanelRow] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = {str(name).strip() for name in (reader.fieldnames or [])}
        missing = sorted(required - headers)
        if missing:
            raise DataContractError(
                f"{path.name}: missing required columns: {', '.join(missing)}"
            )
        for line_number, raw in enumerate(reader, start=2):
            province = (raw.get("province") or "").strip()
            if not province:
                raise DataContractError(f"{path.name}:{line_number}: province is blank")
            raw_week = (raw.get("week_start") or "").strip()
            try:
                week_start = date.fromisoformat(raw_week)
            except ValueError as exc:
                raise DataContractError(
                    f"{path.name}:{line_number}: invalid week_start {raw_week!r}"
                ) from exc
            if week_start.weekday() != 6:
                raise DataContractError(
                    f"{path.name}:{line_number}: {week_start} is not a Sunday week start"
                )

            week_text = (raw.get("week") or "").strip()
            if week_text:
                try:
                    week_number = float(week_text)
                except ValueError as exc:
                    raise DataContractError(
                        f"{path.name}:{line_number}: week must be an integer"
                    ) from exc
                if not math.isfinite(week_number) or not week_number.is_integer():
                    raise DataContractError(
                        f"{path.name}:{line_number}: week must be an integer"
                    )
                week = int(week_number)
                if week < 1 or week > 53:
                    raise DataContractError(
                        f"{path.name}:{line_number}: week must be between 1 and 53"
                    )
            else:
                week = week_start.isocalendar().week

            cases = parse_optional_number(raw.get("cases"), field="cases", line=line_number)
            weather = parse_optional_number(
                raw.get("w_apparent_temperature_mean"),
                field="w_apparent_temperature_mean", line=line_number,
            )
            if cases is not None and cases < 0:
                raise DataContractError(
                    f"{path.name}:{line_number}: cases cannot be negative ({cases})"
                )
            if cases is None and not allow_blank_target_week:
                raise DataContractError(f"{path.name}:{line_number}: cases is blank")
            rows.append(PanelRow(province, week_start, week, cases, weather))

    if not rows:
        raise DataContractError(f"{path.name}: no data rows")
    return sorted(rows, key=lambda row: (row.province, row.week_start))


def validate_panel(
    rows: Sequence[PanelRow], *, label: str, expected_provinces: int = EXPECTED_PROVINCES
) -> dict[str, Any]:
    """Assert a complete, duplicate-free province × Sunday-week panel."""
    province_set = {row.province for row in rows}
    week_set = {row.week_start for row in rows}
    if len(province_set) != expected_provinces:
        raise DataContractError(
            f"{label}: expected {expected_provinces} provinces, found {len(province_set)}"
        )

    seen: set[tuple[str, date]] = set()
    by_week: dict[date, set[str]] = defaultdict(set)
    by_province: dict[str, list[date]] = defaultdict(list)
    blank_targets: list[tuple[str, date]] = []
    blank_weather = 0
    for row in rows:
        if row.key in seen:
            raise DataContractError(
                f"{label}: duplicate province-week row {row.province} / {row.week_start}"
            )
        seen.add(row.key)
        by_week[row.week_start].add(row.province)
        by_province[row.province].append(row.week_start)
        if row.cases is None:
            blank_targets.append(row.key)
        if row.weather is None:
            blank_weather += 1

    ordered_weeks = sorted(week_set)
    expected_provinces_set = province_set
    for week in ordered_weeks:
        if by_week[week] != expected_provinces_set:
            missing = sorted(expected_provinces_set - by_week[week])
            extra = sorted(by_week[week] - expected_provinces_set)
            raise DataContractError(
                f"{label}: {week} does not contain all provinces; missing={missing}, extra={extra}"
            )
    for province, province_weeks in by_province.items():
        province_weeks.sort()
        if province_weeks != ordered_weeks:
            raise DataContractError(
                f"{label}: {province} has a missing or extra epidemiological week"
            )
    for previous, current in zip(ordered_weeks, ordered_weeks[1:]):
        if current - previous != timedelta(days=7):
            raise DataContractError(
                f"{label}: weekly grid gap between {previous} and {current}"
            )

    return {
        "label": label,
        "rows": len(rows),
        "province_count": len(province_set),
        "week_count": len(ordered_weeks),
        "start_week": ordered_weeks[0].isoformat(),
        "end_week": ordered_weeks[-1].isoformat(),
        "duplicate_province_weeks": 0,
        "negative_cases": 0,
        "blank_target_rows": len(blank_targets),
        "blank_weather_rows": blank_weather,
        "weeks_have_all_provinces": True,
        "weekly_continuity": True,
    }


def audit_source_pair(train_rows: Sequence[PanelRow], full_rows: Sequence[PanelRow]) -> dict[str, Any]:
    """Check the intended cut/full relationship without treating extra target rows as leakage.

    `train_rows` must end at week t-1. `full_rows` must contain the same selected
    modelling values for every shared row and one complete target week t. The
    target-week cases may exist in the raw full file as an answer key, but are
    never copied into its feature vector by `build_features`.
    """
    train = validate_panel(train_rows, label="training cut")
    full = validate_panel(full_rows, label="full source")
    train_by_key = {row.key: row for row in train_rows}
    full_by_key = {row.key: row for row in full_rows}

    mismatches: list[str] = []
    for key, train_row in train_by_key.items():
        full_row = full_by_key.get(key)
        if full_row is None:
            mismatches.append(f"missing shared row {key[0]} / {key[1]}")
            if len(mismatches) >= 5:
                break
            continue
        if train_row.week != full_row.week:
            mismatches.append(f"week index differs for {key[0]} / {key[1]}")
        elif train_row.cases != full_row.cases:
            mismatches.append(f"cases differ for {key[0]} / {key[1]}")
        elif train_row.weather is None or full_row.weather is None:
            if train_row.weather != full_row.weather:
                mismatches.append(f"weather missingness differs for {key[0]} / {key[1]}")
        elif not math.isclose(train_row.weather, full_row.weather, rel_tol=1e-10, abs_tol=1e-10):
            mismatches.append(f"weather differs for {key[0]} / {key[1]}")
        if len(mismatches) >= 5:
            break
    if mismatches:
        raise DataContractError("training cut/full source mismatch: " + "; ".join(mismatches))

    train_end = max(row.week_start for row in train_rows)
    full_end = max(row.week_start for row in full_rows)
    if full_end - train_end != timedelta(days=7):
        raise DataContractError(
            f"full source must end exactly one week after training cut; "
            f"training ends {train_end}, full ends {full_end}"
        )
    target_rows = [row for row in full_rows if row.week_start == full_end]
    blank_targets = [row for row in full_rows if row.cases is None]
    if blank_targets:
        if any(row.week_start != full_end for row in blank_targets):
            raise DataContractError("blank cases are only allowed in the full source target week")
        if len(blank_targets) != EXPECTED_PROVINCES:
            raise DataContractError("target-week cases must be either present for all 77 provinces or blank for all 77")
    if len(target_rows) != EXPECTED_PROVINCES:
        raise DataContractError(
            f"full source target week {full_end} has {len(target_rows)} rows; expected 77"
        )
    if {row.province for row in target_rows} != {row.province for row in train_rows}:
        raise DataContractError("full source target week does not match training province coverage")

    return {
        "status": "passed",
        "training_cut": train,
        "full_source": full,
        "shared_rows_compared": len(train_by_key),
        "shared_cases_and_lagged_weather_match": True,
        "training_end_week": train_end.isoformat(),
        "forecast_target_week": full_end.isoformat(),
        "forecast_horizon_weeks": 1,
        "target_week_rows": len(target_rows),
        "target_week_actuals_present_in_raw_full": all(row.cases is not None for row in target_rows),
        "target_week_actuals_used_as_features": False,
    }


def fit_province_baseline(
    rows: Sequence[PanelRow], *, end_week: date | None = None
) -> dict[str, float]:
    totals: dict[str, float] = defaultdict(float)
    counts: dict[str, int] = defaultdict(int)
    for row in rows:
        if row.cases is None or (end_week is not None and row.week_start > end_week):
            continue
        totals[row.province] += row.cases
        counts[row.province] += 1
    result = {
        province: totals[province] / counts[province]
        for province in totals if counts[province]
    }
    if len(result) != EXPECTED_PROVINCES:
        raise DataContractError(
            f"province baseline needs all 77 provinces; found {len(result)}"
        )
    return result


def build_features(
    rows: Sequence[PanelRow], baseline: dict[str, float]
) -> dict[tuple[str, date], FeatureRow]:
    """Build causal one-step features; no current-week case/weather enters X."""
    grouped: dict[str, list[PanelRow]] = defaultdict(list)
    for row in rows:
        grouped[row.province].append(row)
    features: dict[tuple[str, date], FeatureRow] = {}
    for province, province_rows in grouped.items():
        province_rows.sort(key=lambda row: row.week_start)
        base = baseline.get(province)
        if base is None or not math.isfinite(base) or base < 0:
            raise DataContractError(f"invalid train-only baseline for {province}")
        for index, current in enumerate(province_rows):
            if index < max(CASE_LAGS):
                continue
            lag_values: list[float] = []
            valid = True
            for lag in CASE_LAGS:
                value = province_rows[index - lag].cases
                if value is None:
                    valid = False
                    break
                lag_values.append(value)
            previous_weather = province_rows[index - 1].weather
            if not valid or previous_weather is None:
                continue
            relative_1 = lag_values[0] / (base + 1.0)
            relative_2 = lag_values[1] / (base + 1.0)
            momentum = relative_1 / (relative_2 + 0.1)
            angle = 2.0 * math.pi * current.week / 52.0
            vector = tuple(lag_values + [
                momentum,
                relative_1,
                relative_2,
                math.sin(angle),
                math.cos(angle),
                previous_weather,
            ])
            if len(vector) != len(FEATURES) or not all(math.isfinite(v) for v in vector):
                raise DataContractError(f"non-finite or malformed feature row: {province}/{current.week_start}")
            features[current.key] = FeatureRow(
                province=province,
                week_start=current.week_start,
                week=current.week,
                target=current.cases,
                values=vector,
            )
    return features


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def current_epi_week_bangkok(now: datetime | None = None) -> date:
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None or current.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    local_date = (current.astimezone(timezone.utc) + timedelta(hours=7)).date()
    return local_date - timedelta(days=(local_date.weekday() + 1) % 7)


def make_cv_folds(
    development_weeks: Sequence[date], *, n_folds: int, validation_weeks: int, gap_weeks: int
) -> list[tuple[date, set[date]]]:
    if n_folds < 2 or validation_weeks < 1 or gap_weeks < 1:
        raise DataContractError("CV requires at least two folds, one validation week, and a positive gap")
    required = n_folds * validation_weeks
    first_start = len(development_weeks) - required
    if first_start - gap_weeks - 1 < 52:
        raise DataContractError(
            "not enough development history for the requested CV folds and embargo gap"
        )
    folds: list[tuple[date, set[date]]] = []
    for fold_index in range(n_folds):
        start_index = first_start + fold_index * validation_weeks
        end_index = start_index + validation_weeks
        train_end_index = start_index - gap_weeks - 1
        if end_index > len(development_weeks):
            raise DataContractError("CV fold extends beyond the development window")
        train_end = development_weeks[train_end_index]
        validation = set(development_weeks[start_index:end_index])
        folds.append((train_end, validation))
    return folds


def _numpy_lightgbm():
    try:
        import numpy as np
        import lightgbm as lgb
    except ImportError as exc:
        raise RuntimeError(
            "Training dependencies are missing. Install numpy and lightgbm using "
            "scripts/requirements-model-pipeline.txt"
        ) from exc
    return np, lgb


def model_params(objective: str, *, seed: int = 42) -> dict[str, Any]:
    params: dict[str, Any] = {
        "objective": objective,
        "metric": "None",
        "learning_rate": 0.05,
        "num_leaves": 31,
        "min_data_in_leaf": 30,
        "feature_fraction": 0.9,
        "bagging_fraction": 0.9,
        "bagging_freq": 1,
        "lambda_l1": 0.1,
        "lambda_l2": 1.0,
        "max_depth": 6,
        "verbosity": -1,
        "seed": seed,
        "feature_fraction_seed": seed,
        "bagging_seed": seed,
        "data_random_seed": seed,
        "num_threads": 1,
        "force_col_wise": True,
    }
    if objective == "quantile":
        params["alpha"] = 0.5
    return params


def _arrays(feature_rows: Sequence[FeatureRow]):
    np, _ = _numpy_lightgbm()
    x = np.asarray([row.values for row in feature_rows], dtype=np.float32)
    y = np.asarray([row.target for row in feature_rows], dtype=np.float32)
    if x.ndim != 2 or x.shape[1] != len(FEATURES):
        raise DataContractError(f"feature matrix has unexpected shape {x.shape}")
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise DataContractError("feature matrix or target contains a non-finite value")
    return x, y


def fit_lightgbm(feature_rows: Sequence[FeatureRow], *, objective: str, rounds: int, seed: int):
    np, lgb = _numpy_lightgbm()
    if not feature_rows:
        raise DataContractError("cannot fit a model with zero usable rows")
    x, y = _arrays(feature_rows)
    dataset = lgb.Dataset(x, label=y, free_raw_data=False)
    return lgb.train(model_params(objective, seed=seed), dataset, num_boost_round=rounds)


def predict_lightgbm(model: Any, feature_rows: Sequence[FeatureRow]) -> list[float]:
    np, _ = _numpy_lightgbm()
    x = np.asarray([row.values for row in feature_rows], dtype=np.float32)
    values = model.predict(x)
    predictions = [max(0.0, float(value)) for value in values]
    if not all(math.isfinite(value) for value in predictions):
        raise DataContractError("model generated a non-finite prediction")
    return predictions


def metric_summary(actual: Sequence[float], predicted: Sequence[float]) -> dict[str, float]:
    if not actual or len(actual) != len(predicted):
        raise DataContractError("metrics require equally sized non-empty actual/predicted vectors")
    errors = [float(y) - float(p) for y, p in zip(actual, predicted)]
    absolute = [abs(error) for error in errors]
    mae = statistics.fmean(absolute)
    rmse = math.sqrt(statistics.fmean(error * error for error in errors))
    denominator = sum(abs(value) for value in actual)
    wape = sum(absolute) / denominator if denominator else 0.0
    bias = statistics.fmean([float(p) - float(y) for y, p in zip(actual, predicted)])
    return {"mae": mae, "rmse": rmse, "wape": wape, "bias_pred_minus_actual": bias}


def paired_week_bootstrap(
    holdout_rows: Sequence[FeatureRow],
    model_predictions: Sequence[float],
    baseline_predictions: Sequence[float],
    *, seed: int = 42,
    replicates: int = 2000,
) -> list[float]:
    if not (len(holdout_rows) == len(model_predictions) == len(baseline_predictions)):
        raise DataContractError("bootstrap inputs must have equal lengths")
    grouped: dict[date, list[int]] = defaultdict(list)
    for index, row in enumerate(holdout_rows):
        grouped[row.week_start].append(index)
    weeks = sorted(grouped)
    if len(weeks) < 2:
        return [0.0, 0.0]
    model_abs = [abs(float(row.target) - pred) for row, pred in zip(holdout_rows, model_predictions)]
    base_abs = [abs(float(row.target) - pred) for row, pred in zip(holdout_rows, baseline_predictions)]
    rng = random.Random(seed)
    samples: list[float] = []
    for _ in range(replicates):
        selected = [rng.choice(weeks) for _ in weeks]
        indices = [index for week in selected for index in grouped[week]]
        samples.append(statistics.fmean(model_abs[i] - base_abs[i] for i in indices))
    samples.sort()
    lower = samples[int(0.025 * (replicates - 1))]
    upper = samples[int(0.975 * (replicates - 1))]
    return [lower, upper]


def _baseline_predictions(
    rows: Sequence[PanelRow],
    target_rows: Sequence[FeatureRow],
    *, train_end: date,
) -> dict[str, list[float]]:
    history = {(row.province, row.week_start): row.cases for row in rows if row.cases is not None}
    train = [row for row in rows if row.week_start <= train_end and row.cases is not None]
    province_avg: dict[str, list[float]] = defaultdict(list)
    seasonal_avg: dict[tuple[str, int], list[float]] = defaultdict(list)
    for row in train:
        province_avg[row.province].append(float(row.cases))
        seasonal_avg[(row.province, row.week)].append(float(row.cases))
    province_mean = {p: statistics.fmean(v) for p, v in province_avg.items()}
    seasonal_mean = {key: statistics.fmean(values) for key, values in seasonal_avg.items()}

    persistence: list[float] = []
    seasonal: list[float] = []
    climatology: list[float] = []
    for item in target_rows:
        prior = history.get((item.province, item.week_start - timedelta(days=7)))
        year_prior = history.get((item.province, item.week_start - timedelta(days=364)))
        fallback = province_mean[item.province]
        persistence.append(float(prior if prior is not None else fallback))
        seasonal.append(float(year_prior if year_prior is not None else seasonal_mean.get((item.province, item.week), fallback)))
        climatology.append(float(seasonal_mean.get((item.province, item.week), fallback)))
    return {"persistence": persistence, "seasonal_naive": seasonal, "climatology": climatology}


def assert_feature_week_coverage(
    feature_rows: Sequence[FeatureRow], expected_weeks: Iterable[date], *, label: str
) -> None:
    """Fail closed if any evaluation week lacks one feature row per province."""
    by_week: dict[date, set[str]] = defaultdict(set)
    for row in feature_rows:
        by_week[row.week_start].add(row.province)
    expected_provinces = EXPECTED_PROVINCES
    for week in sorted(set(expected_weeks)):
        actual = by_week.get(week, set())
        if len(actual) != expected_provinces:
            raise DataContractError(
                f"{label}: {week} has {len(actual)} usable province feature rows; "
                f"expected exactly {expected_provinces}. Check lagged weather/case completeness."
            )


def _records_for_dates(
    feature_map: dict[tuple[str, date], FeatureRow], dates: set[date]
) -> list[FeatureRow]:
    return sorted(
        [row for key, row in feature_map.items() if row.week_start in dates and row.target is not None],
        key=lambda row: (row.week_start, row.province),
    )


def _rows_for_training(
    feature_map: dict[tuple[str, date], FeatureRow], end_week: date
) -> list[FeatureRow]:
    return sorted(
        [row for row in feature_map.values() if row.week_start <= end_week and row.target is not None],
        key=lambda row: (row.week_start, row.province),
    )


def cross_validate(
    train_rows: Sequence[PanelRow],
    *, holdout_weeks: int,
    n_folds: int,
    validation_weeks: int,
    gap_weeks: int,
    seed: int,
    candidates: Sequence[tuple[str, int]],
) -> tuple[tuple[str, int], list[dict[str, Any]]]:
    weeks = sorted({row.week_start for row in train_rows})
    if holdout_weeks < 8 or holdout_weeks >= len(weeks) // 2:
        raise DataContractError("holdout-weeks must be at least 8 and less than half the history")
    development_weeks = weeks[:-holdout_weeks]
    folds = make_cv_folds(
        development_weeks, n_folds=n_folds,
        validation_weeks=validation_weeks, gap_weeks=gap_weeks,
    )
    fold_results: list[dict[str, Any]] = []
    candidate_scores: dict[tuple[str, int], list[float]] = {candidate: [] for candidate in candidates}

    for fold_number, (train_end, validation_dates) in enumerate(folds, start=1):
        baseline = fit_province_baseline(train_rows, end_week=train_end)
        feature_map = build_features(train_rows, baseline)
        training = _rows_for_training(feature_map, train_end)
        validation = _records_for_dates(feature_map, validation_dates)
        assert_feature_week_coverage(training, {row.week_start for row in training}, label=f"CV fold {fold_number} training")
        assert_feature_week_coverage(validation, validation_dates, label=f"CV fold {fold_number} validation")
        if not training or not validation:
            raise DataContractError(f"CV fold {fold_number} has no usable train or validation rows")
        actual = [float(row.target) for row in validation]
        candidate_fold: list[dict[str, Any]] = []
        for objective, rounds in candidates:
            model = fit_lightgbm(training, objective=objective, rounds=rounds, seed=seed)
            predictions = predict_lightgbm(model, validation)
            score = metric_summary(actual, predictions)
            candidate_scores[(objective, rounds)].append(score["mae"])
            candidate_fold.append({
                "objective": objective,
                "rounds": rounds,
                **score,
            })
            del model
        fold_results.append({
            "fold": fold_number,
            "train_end_week": train_end.isoformat(),
            "validation_start_week": min(validation_dates).isoformat(),
            "validation_end_week": max(validation_dates).isoformat(),
            "gap_weeks": gap_weeks,
            "train_rows": len(training),
            "validation_rows": len(validation),
            "baseline_fitted_through": train_end.isoformat(),
            "candidate_scores": candidate_fold,
        })

    scored = [
        (statistics.fmean(scores), candidate[0], candidate[1])
        for candidate, scores in candidate_scores.items()
    ]
    scored.sort(key=lambda item: (item[0], item[1], item[2]))
    best = (scored[0][1], scored[0][2])
    return best, fold_results


def train_pipeline(
    train_csv: Path,
    full_csv: Path,
    output_dir: Path,
    *,
    source_commit: str,
    source_ref: str,
    source_description: str,
    holdout_weeks: int = 26,
    n_folds: int = 4,
    validation_weeks: int = 8,
    gap_weeks: int = 4,
    seed: int = 42,
    rounds_grid: Sequence[int] = (400, 600, 800),
    require_current: bool = False,
) -> dict[str, Any]:
    if not re.fullmatch(r"[0-9a-fA-F]{40}", source_commit):
        raise DataContractError("--source-commit must be a 40-character hexadecimal Git commit SHA")
    if not source_ref.strip():
        raise DataContractError("--source-ref must be non-empty")

    train_rows = read_panel(train_csv)
    full_rows = read_panel(full_csv, allow_blank_target_week=True)
    audit = audit_source_pair(train_rows, full_rows)
    ordered_weeks = sorted({row.week_start for row in train_rows})
    forecast_week = max(row.week_start for row in full_rows)
    train_end = max(ordered_weeks)
    if forecast_week != train_end + timedelta(days=7):
        raise DataContractError("forecast target week must immediately follow the final training week")

    current_week = current_epi_week_bangkok()
    if require_current and forecast_week != current_week:
        raise DataContractError(
            f"--require-current blocked output: dataset targets {forecast_week}, "
            f"but the current epidemiological week in Asia/Bangkok is {current_week}"
        )

    candidates = [(objective, rounds) for objective in ("quantile", "poisson") for rounds in rounds_grid]
    best, fold_results = cross_validate(
        train_rows,
        holdout_weeks=holdout_weeks,
        n_folds=n_folds,
        validation_weeks=validation_weeks,
        gap_weeks=gap_weeks,
        seed=seed,
        candidates=candidates,
    )

    # Final retrospective holdout is not used for CV model selection.
    holdout_start = ordered_weeks[-holdout_weeks]
    holdout_train_end = ordered_weeks[-holdout_weeks - 1]
    holdout_baseline = fit_province_baseline(train_rows, end_week=holdout_train_end)
    holdout_features = build_features(train_rows, holdout_baseline)
    holdout_training = _rows_for_training(holdout_features, holdout_train_end)
    holdout_dates = set(ordered_weeks[-holdout_weeks:])
    holdout_records = _records_for_dates(holdout_features, holdout_dates)
    assert_feature_week_coverage(holdout_records, holdout_dates, label="retrospective holdout")
    holdout_model = fit_lightgbm(
        holdout_training, objective=best[0], rounds=best[1], seed=seed
    )
    holdout_predictions = predict_lightgbm(holdout_model, holdout_records)
    holdout_actual = [float(row.target) for row in holdout_records]
    holdout_baselines = _baseline_predictions(
        train_rows, holdout_records, train_end=holdout_train_end
    )
    holdout_metrics = metric_summary(holdout_actual, holdout_predictions)
    baseline_metrics = {
        name: metric_summary(holdout_actual, values)
        for name, values in holdout_baselines.items()
    }
    paired_ci = paired_week_bootstrap(
        holdout_records,
        holdout_predictions,
        holdout_baselines["persistence"],
        seed=seed,
    )
    persistence_mae = baseline_metrics["persistence"]["mae"]
    skill = (
        (persistence_mae - holdout_metrics["mae"]) / persistence_mae * 100.0
        if persistence_mae > 0 else 0.0
    )

    per_province: list[dict[str, Any]] = []
    province_groups: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(holdout_records):
        province_groups[row.province].append(index)
    for province, indexes in sorted(province_groups.items()):
        province_summary = metric_summary(
            [holdout_actual[i] for i in indexes],
            [holdout_predictions[i] for i in indexes],
        )
        per_province.append({"province": province, **province_summary, "n_weeks": len(indexes)})

    # Refit the operational model on every eligible labelled week in the cut file.
    final_baseline = fit_province_baseline(train_rows, end_week=train_end)
    final_features = build_features(train_rows, final_baseline)
    final_training = _rows_for_training(final_features, train_end)
    final_model = fit_lightgbm(final_training, objective=best[0], rounds=best[1], seed=seed)

    # Blank all labels from the target week before feature generation. Only
    # lagged values from preceding weeks can enter the 12 feature columns.
    forecast_rows = [
        PanelRow(row.province, row.week_start, row.week, None if row.week_start == forecast_week else row.cases, row.weather)
        for row in full_rows
    ]
    forecast_features = build_features(forecast_rows, final_baseline)
    target_features = sorted(
        [row for row in forecast_features.values() if row.week_start == forecast_week],
        key=lambda row: row.province,
    )
    if len(target_features) != EXPECTED_PROVINCES:
        raise DataContractError(
            f"target-week feature matrix contains {len(target_features)} rows; expected 77"
        )
    forecast_predictions = predict_lightgbm(final_model, target_features)

    input_hash = hashlib.sha256(
        (sha256_file(train_csv) + sha256_file(full_csv)).encode("ascii")
    ).hexdigest()
    generated_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    is_current = forecast_week == current_week
    metrics: dict[str, Any] = {
        "schema_version": 1,
        "model_name": "DenguYosoku 77-province LightGBM weekly nowcast",
        "model_revision": source_commit.lower(),
        "dataset_source": source_description,
        "dataset_source_url": TANRABAD_SOURCE,
        "data_permission_note": "Project maintainer confirmed permission from the source repository owner to use the repository data for model development; this does not assert an independent blanket licence for onward raw-data redistribution.",
        "generated_at_utc": generated_at,
        "train_start_week": min(ordered_weeks).isoformat(),
        "train_end_week": train_end.isoformat(),
        "holdout_start_week": holdout_start.isoformat(),
        "eval_cutoff": max(holdout_dates).isoformat(),
        "evaluation_protocol": "retrospective rolling-origin one-week-ahead holdout; public historical data, not a sealed independent blind test",
        "forecast_week": forecast_week.isoformat(),
        "input_data_through_week": train_end.isoformat(),
        "forecast_status": "current_candidate" if is_current else "stale_historical_rehearsal",
        "current_epidemiological_week_asia_bangkok": current_week.isoformat(),
        "n_train": len(final_training),
        "n_test": len(holdout_records),
        "province_count": EXPECTED_PROVINCES,
        "features": list(FEATURES),
        "case_lags": list(CASE_LAGS),
        "objective": "quantile50" if best[0] == "quantile" else best[0],
        "best_iteration": best[1],
        "seed": seed,
        **holdout_metrics,
        "baseline_metrics": baseline_metrics,
        "baseline_mae": {name: value["mae"] for name, value in baseline_metrics.items()},
        "skill_vs_persistence_pct": skill,
        "paired_dmae_model_minus_persistence": holdout_metrics["mae"] - persistence_mae,
        "paired_dmae_ci95": paired_ci,
        "per_province_holdout": per_province,
        "cross_validation": {
            "selection_metric": "mean fold MAE",
            "fold_count": len(fold_results),
            "validation_weeks_per_fold": validation_weeks,
            "embargo_gap_weeks": gap_weeks,
            "baseline_recomputed_per_fold_from_training_only": True,
            "folds": fold_results,
        },
        "source_data_sha256": {
            "training_cut": sha256_file(train_csv),
            "full_source": sha256_file(full_csv),
            "combined_input_sha256": input_hash,
        },
        "source_repository": SOURCE_REPOSITORY,
        "source_ref": source_ref,
        "source_commit_sha": source_commit.lower(),
    }
    if is_current:
        metrics["operational_release"] = {
            "release_type": "nowcast",
            "forecast_week": forecast_week.isoformat(),
            "input_data_through_week": train_end.isoformat(),
            "input_data_ref": f"TanRabad export bundle; source commit {source_commit.lower()}",
            "input_data_sha256": input_hash,
            "generated_at_utc": generated_at,
        }

    output_dir.mkdir(parents=True, exist_ok=True)
    holdout_path = output_dir / "holdout_predictions.csv"
    forecast_path = output_dir / "predictions.csv"
    metrics_path = output_dir / "metrics.json"
    audit_path = output_dir / "data_audit.json"
    manifest_path = output_dir / "training_manifest.json"
    model_path = output_dir / "model.txt"

    with holdout_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[
            "province", "week_start", "year", "cases", "pred", "persist",
            "seasonal_naive", "climatology", "residual",
        ])
        writer.writeheader()
        for row, prediction, persistence, seasonal, climatology in zip(
            holdout_records,
            holdout_predictions,
            holdout_baselines["persistence"],
            holdout_baselines["seasonal_naive"],
            holdout_baselines["climatology"],
        ):
            writer.writerow({
                "province": row.province,
                "week_start": row.week_start.isoformat(),
                "year": row.week_start.year,
                "cases": float(row.target),
                "pred": prediction,
                "persist": persistence,
                "seasonal_naive": seasonal,
                "climatology": climatology,
                "residual": float(row.target) - prediction,
            })

    with forecast_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["province", "week_start", "pred"])
        writer.writeheader()
        for row, prediction in zip(target_features, forecast_predictions):
            writer.writerow({
                "province": row.province,
                "week_start": forecast_week.isoformat(),
                "pred": prediction,
            })

    audit.update({
        "train_csv": str(train_csv),
        "full_csv": str(full_csv),
        "train_csv_sha256": sha256_file(train_csv),
        "full_csv_sha256": sha256_file(full_csv),
        "source_commit_sha": source_commit.lower(),
    })
    audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    metrics_path.write_text(json.dumps(metrics, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    manifest = {
        "manifest_type": "training_run_manifest_not_publication_manifest",
        "source_repository": SOURCE_REPOSITORY,
        "source_ref": source_ref,
        "source_commit_sha": source_commit.lower(),
        "dataset_source": source_description,
        "dataset_source_url": TANRABAD_SOURCE,
        "data_permission_note": "Project maintainer confirmed permission from the source repository owner to use the repository data for model development; this does not assert an independent blanket licence for onward raw-data redistribution.",
        "generated_at_utc": generated_at,
        "input_files": {
            "training_cut": {"path": str(train_csv), "sha256": audit["train_csv_sha256"], "role": "labelled training panel through week t-1"},
            "full_source": {"path": str(full_csv), "sha256": audit["full_csv_sha256"], "role": "history plus forecast target week t; target labels blanked before feature generation"},
        },
        "outputs": {
            path.name: {"size_bytes": path.stat().st_size, "sha256": sha256_file(path)}
            for path in (holdout_path, forecast_path, metrics_path, audit_path)
        },
        "publication_note": "This is a local/CI training run manifest. It is not the source_manifest.json required by the website importer and must not be treated as a published model release.",
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    final_model.save_model(str(model_path))

    summary = {
        "status": "completed",
        "audit": audit,
        "selected_model": {"objective": best[0], "rounds": best[1]},
        "holdout_metrics": holdout_metrics,
        "baseline_mae": {name: value["mae"] for name, value in baseline_metrics.items()},
        "skill_vs_persistence_pct": skill,
        "forecast_week": forecast_week.isoformat(),
        "current_week": current_week.isoformat(),
        "forecast_status": metrics["forecast_status"],
        "forecast_rows": len(forecast_predictions),
        "output_dir": str(output_dir),
    }
    if require_current and not is_current:
        # This is defensive: the check above should already have failed.
        raise DataContractError("current-release guard failed after training")
    return summary


def command_audit(args: argparse.Namespace) -> int:
    train_rows = read_panel(Path(args.train_csv))
    full_rows = read_panel(Path(args.full_csv), allow_blank_target_week=True)
    report = audit_source_pair(train_rows, full_rows)
    report["train_csv_sha256"] = sha256_file(Path(args.train_csv))
    report["full_csv_sha256"] = sha256_file(Path(args.full_csv))
    if args.output:
        destination = Path(args.output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def command_train(args: argparse.Namespace) -> int:
    summary = train_pipeline(
        Path(args.train_csv),
        Path(args.full_csv),
        Path(args.output_dir),
        source_commit=args.source_commit,
        source_ref=args.source_ref,
        source_description=args.source_description,
        holdout_weeks=args.holdout_weeks,
        n_folds=args.cv_folds,
        validation_weeks=args.cv_weeks,
        gap_weeks=args.gap_weeks,
        seed=args.seed,
        rounds_grid=tuple(int(value) for value in args.rounds.split(",")),
        require_current=args.require_current,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if summary["forecast_status"] != "current_candidate":
        print(
            "WARNING: generated forecast is a historical rehearsal, not a current operational nowcast.",
            file=sys.stderr,
        )
    print(
        "NOTE: holdout data is public historical data; this run does not claim a sealed independent blind test.",
        file=sys.stderr,
    )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DengueYosoku 77-province model pipeline")
    sub = parser.add_subparsers(dest="command", required=True)
    audit = sub.add_parser("audit", help="audit training-cut and full source CSVs")
    audit.add_argument("--train-csv", required=True)
    audit.add_argument("--full-csv", required=True)
    audit.add_argument("--output")
    audit.set_defaults(func=command_audit)

    train = sub.add_parser("train", help="run CV, temporal holdout and one-week forecast")
    train.add_argument("--train-csv", required=True)
    train.add_argument("--full-csv", required=True)
    train.add_argument("--output-dir", required=True)
    train.add_argument("--source-commit", required=True)
    train.add_argument("--source-ref", default="main")
    train.add_argument("--source-description", default="TanRabad / Department of Disease Control dengue surveillance export; attribution supplied by project maintainer")
    train.add_argument("--holdout-weeks", type=int, default=26)
    train.add_argument("--cv-folds", type=int, default=4)
    train.add_argument("--cv-weeks", type=int, default=8)
    train.add_argument("--gap-weeks", type=int, default=4)
    train.add_argument("--rounds", default="400,600,800", help="comma-separated LightGBM boosting rounds")
    train.add_argument("--seed", type=int, default=42)
    train.add_argument("--require-current", action="store_true")
    train.set_defaults(func=command_train)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (DataContractError, FileNotFoundError, OSError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
