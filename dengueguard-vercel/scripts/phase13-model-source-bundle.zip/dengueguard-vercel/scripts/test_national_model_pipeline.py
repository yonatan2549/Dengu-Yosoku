#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standard-library contract tests for the 77-province dengue model pipeline."""
from __future__ import annotations

import csv
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

try:
    from . import national_model_pipeline as pipeline
except ImportError:  # direct execution from scripts/
    import national_model_pipeline as pipeline


PROVINCES = [f"จังหวัด-{index:02d}" for index in range(1, 78)]


def write_panel(path: Path, *, weeks: int, start: date = date(2025, 1, 5), blank_last_target: bool = False, offset: int = 0):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[
            "province", "week", "week_start", "cases", "w_apparent_temperature_mean", "population", "extra_source_column"
        ])
        writer.writeheader()
        for province_index, province in enumerate(PROVINCES):
            for week_index in range(weeks):
                week_start = start + timedelta(days=week_index * 7)
                value = float(offset + province_index + week_index + 1)
                cases = "" if blank_last_target and week_index == weeks - 1 else value
                writer.writerow({
                    "province": province,
                    "week": week_start.isocalendar().week,
                    "week_start": week_start.isoformat(),
                    "cases": cases,
                    "w_apparent_temperature_mean": 27.0 + week_index / 100,
                    "population": 100000,
                    "extra_source_column": "ignored-by-model",
                })


class NationalModelPipelineTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_audit_accepts_cut_and_full_with_one_target_week(self):
        train = self.root / "train.csv"
        full = self.root / "full.csv"
        write_panel(train, weeks=20)
        write_panel(full, weeks=21)

        train_rows = pipeline.read_panel(train)
        full_rows = pipeline.read_panel(full)
        result = pipeline.audit_source_pair(train_rows, full_rows)

        self.assertEqual(result["status"], "passed")
        self.assertEqual(result["training_cut"]["rows"], 77 * 20)
        self.assertEqual(result["full_source"]["rows"], 77 * 21)
        self.assertEqual(result["forecast_horizon_weeks"], 1)
        self.assertFalse(result["target_week_actuals_used_as_features"])

    def test_audit_detects_mismatch_in_shared_history(self):
        train = self.root / "train.csv"
        full = self.root / "full.csv"
        write_panel(train, weeks=20)
        write_panel(full, weeks=21)
        rows = full.read_text(encoding="utf-8-sig").splitlines()
        # Change one source case in a shared week without altering the schema.
        cells = rows[1].split(",")
        cells[3] = str(float(cells[3]) + 1)
        rows[1] = ",".join(cells)
        full.write_text("\n".join(rows) + "\n", encoding="utf-8-sig")

        with self.assertRaisesRegex(pipeline.DataContractError, "source mismatch"):
            pipeline.audit_source_pair(pipeline.read_panel(train), pipeline.read_panel(full))

    def test_panel_rejects_duplicate_province_week(self):
        path = self.root / "duplicate.csv"
        write_panel(path, weeks=14)
        with path.open("a", encoding="utf-8") as handle:
            handle.write("จังหวัด-01,3,2025-01-19,999,28,100000,duplicate\n")
        with self.assertRaisesRegex(pipeline.DataContractError, "duplicate province-week"):
            pipeline.validate_panel(pipeline.read_panel(path), label="duplicate test")

    def test_panel_rejects_incomplete_province_week(self):
        path = self.root / "incomplete.csv"
        write_panel(path, weeks=14)
        lines = path.read_text(encoding="utf-8-sig").splitlines()
        del lines[-1]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
        with self.assertRaisesRegex(pipeline.DataContractError, "does not contain all provinces"):
            pipeline.validate_panel(pipeline.read_panel(path), label="incomplete test")

    def test_target_week_actual_does_not_enter_feature_vector(self):
        train = self.root / "train.csv"
        full = self.root / "full.csv"
        write_panel(train, weeks=20)
        write_panel(full, weeks=21)
        full_rows = pipeline.read_panel(full)
        target_week = max(row.week_start for row in full_rows)
        blanked = [
            pipeline.PanelRow(row.province, row.week_start, row.week,
                              None if row.week_start == target_week else row.cases,
                              row.weather)
            for row in full_rows
        ]
        baseline = pipeline.fit_province_baseline(pipeline.read_panel(train))
        built = pipeline.build_features(blanked, baseline)
        target_features = [row for row in built.values() if row.week_start == target_week]
        self.assertEqual(len(target_features), 77)
        self.assertTrue(all(row.target is None for row in target_features))
        # L1 must be the previous week, while no feature equals the blanked current target.
        expected_l1 = {row.province: row.cases for row in full_rows if row.week_start == target_week - timedelta(days=7)}
        for row in target_features:
            self.assertEqual(row.values[0], expected_l1[row.province])
            self.assertEqual(len(row.values), 12)

    def test_baseline_is_fit_only_through_requested_week(self):
        train = self.root / "train.csv"
        write_panel(train, weeks=20)
        rows = pipeline.read_panel(train)
        end = date(2025, 1, 5) + timedelta(days=9 * 7)
        baseline = pipeline.fit_province_baseline(rows, end_week=end)
        province_rows = [row.cases for row in rows if row.province == PROVINCES[0] and row.week_start <= end]
        self.assertEqual(baseline[PROVINCES[0]], sum(province_rows) / len(province_rows))

    def test_full_file_must_be_exactly_one_week_after_training_cut(self):
        train = self.root / "train.csv"
        full = self.root / "full.csv"
        write_panel(train, weeks=20)
        write_panel(full, weeks=22)
        with self.assertRaisesRegex(pipeline.DataContractError, "exactly one week after"):
            pipeline.audit_source_pair(pipeline.read_panel(train), pipeline.read_panel(full))

    def test_audit_accepts_target_week_actuals_blank_for_all_provinces(self):
        train = self.root / "train.csv"
        full = self.root / "full.csv"
        write_panel(train, weeks=20)
        write_panel(full, weeks=21, blank_last_target=True)
        report = pipeline.audit_source_pair(pipeline.read_panel(train), pipeline.read_panel(full, allow_blank_target_week=True))
        self.assertFalse(report["target_week_actuals_present_in_raw_full"])
        self.assertFalse(report["target_week_actuals_used_as_features"])

    def test_audit_rejects_partial_target_week_actuals(self):
        train = self.root / "train.csv"
        full = self.root / "full.csv"
        write_panel(train, weeks=20)
        write_panel(full, weeks=21)
        rows = full.read_text(encoding="utf-8-sig").splitlines()
        cells = rows[-1].split(",")
        cells[3] = ""
        rows[-1] = ",".join(cells)
        full.write_text("\n".join(rows) + "\n", encoding="utf-8-sig")
        with self.assertRaisesRegex(pipeline.DataContractError, "either present for all 77 provinces or blank for all 77"):
            pipeline.audit_source_pair(pipeline.read_panel(train), pipeline.read_panel(full, allow_blank_target_week=True))

    def test_fractional_epidemiological_week_is_rejected(self):
        path = self.root / "fractional-week.csv"
        write_panel(path, weeks=14)
        lines = path.read_text(encoding="utf-8-sig").splitlines()
        cells = lines[1].split(",")
        cells[1] = "1.5"
        lines[1] = ",".join(cells)
        path.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
        with self.assertRaisesRegex(pipeline.DataContractError, "week must be an integer"):
            pipeline.read_panel(path)

    def test_feature_coverage_rejects_a_week_with_missing_province(self):
        row = pipeline.FeatureRow(
            province=PROVINCES[0], week_start=date(2025, 1, 5), week=1,
            target=1.0, values=(1.0,) * len(pipeline.FEATURES),
        )
        with self.assertRaisesRegex(pipeline.DataContractError, "expected exactly 77"):
            pipeline.assert_feature_week_coverage([row], {date(2025, 1, 5)}, label="coverage test")

    def test_current_epidemiological_week_uses_bangkok_date(self):
        moment = pipeline.datetime(2026, 11, 21, 14, 0, tzinfo=pipeline.timezone.utc)
        self.assertEqual(pipeline.current_epi_week_bangkok(moment), date(2026, 11, 15))


if __name__ == "__main__":
    unittest.main(verbosity=2)
